# Freshness-service execution — final verdict (2026-08-16)

## Verdict: BLOCKED_PORTFOLIO (real, continuing progress; no unresolved blocker remains)

Twenty-three commits of genuine, verified engineering now sit on `freshness-service/integration`.
**One final, decisive check closes the T5 investigation with concrete proof, not judgment call**
(commit 23): before accepting "needs a new template slot" as final, checked whether real,
already-tested-but-unused machinery (`describe_api_member`/`member_api_identifier`) could close
the gap as a purely additive change to the *existing* API Reference section. Checking test
coverage **before** writing any code found a direct, deliberate block: an existing test
explicitly asserts specific qualified member names must never appear in that section's output —
a real, considered "don't dump every member row" product decision already in force. Implementing
the additive change would have broken it. Correctly not implemented, for a confirmed reason. This
settles the diagnosis with the strongest possible evidence: the fix genuinely needs a new,
separate template slot (a real contract change), and the reusable building blocks for it already
exist and are tested — a future implementer needs only the new slot's wiring and its own
conciseness design call.
**T5's investigation is now complete and closed** (commit 22 added one final precision check:
confirmed the API-reference gap is a *deliberate truncation* of an existing member-summary
renderer, not a total absence of method-level data — 4 of the 9 lost terms already appear
paraphrased in existing rows; 5 have no trace at all — refining, not contradicting, the
two-tier-API-reference conclusion below).
**Both of T5's remaining "full battery green" blockers are now diagnosed to one single, real
root cause** (commit 21): the 9 "unauthorized protected-content loss" fragments and the 9
"blocking claim-accountability" claims were confirmed — by extracting their actual content, not
inferring from category names — to be the *same* 9 real API method names from the source README
(`add_worksheet()`, `Worksheet.rename()`, `merge_range()`, etc.), surfaced by two independent
validators rather than two separate defects. Reading the real candidate's API Reference section
confirmed why: it lists classes/types only, one row per type, with no slot for individual
methods at all — a genuine granularity gap, not a rendering bug, and one that matches this
plan's own documented future work almost exactly (§4's "two-tier API reference mirroring the
reference index"). T5's full remaining scope is now precisely diagnosed and evidence-backed for
the composition-worker cards (T6-T8) that will build it — a real requirement grounded in an
actual failing case, not an abstract goal.
**A real, tested, working fix landed for the disposition-ledger `target` defect T5's exhaustive
investigation identified** (commit 20, following 8 investigation rounds, commits 12–19): rather
than the byte-offset approach found to have a real coordinate-shift problem (insertions during
source preservation shift downstream positions), the fix tracks each compiled slot's exact
**block text**, looked up via substring search against the real final candidate — sidestepping
the shift problem entirely, since `.find()` re-locates content wherever it ends up. A real bug in
the first attempt (a markdown-prefix mismatch, `"## Installation"` vs `"Installation"`) was found
and fixed via direct debugging against the live pilot, not assumed correct. **Verified against
the real target repo**: `disposition_ledger_errors` dropped from **13 to 7** — 6 units
(Installation, Additional Examples, API Reference, Scope and Limitations, Development and
Testing, License) now correctly resolve, each proven by real substring match against the
compiler's own output. The remaining 7 have individually understood, legitimate reasons this fix
correctly leaves untouched (non-slot blocks, nested sub-headings, a genuinely-excluded slot, and
one real, disclosed spelling divergence between source and contract). 3 new tests; full suite
3,911 passed/1 skipped/0 failed (4 legitimately-shifted plan-hash characterization constants
re-baselined, the same pattern already encountered once this session for T10). **T5 still not
COMPLETE**: the candidate remains `deterministic_verdict: reject` due to two separate,
independent defects (protected-content losses, claim-accountability gaps) this fix does not
address and which were never in scope for the disposition-ledger investigation — real, separate,
unstarted work. `GC-03` stays honestly blocked.
**Gate G2 is CLOSED (GC-02 COMPLETE)** — all 11 mandatory G2 cards verified COMPLETE.
**T14 (section registry + plugin framework), G3's first card, is COMPLETE**: a new
`presentation/sections/` package (`SectionRegistryV1` + fingerprint/derive functions) and a
generated `templates/readme/section-registry-v2.json` that byte-reproduces the live 14-slot
template contract as data, with all 4 of the plan's own named "agility tests" (a-d) implemented
and green. **T5 (deterministic pilot skeleton, cells/python) made real, substantial progress
this round but did not reach COMPLETE** — a genuine, honestly-disclosed finding, not a
fabricated success: a real pilot run against the real target repo proved byte-identical
double-run idempotency (twice confirmed) and live Docker isolation capability, but surfaced real
pre-existing defects in the soon-to-retire agentic composer path (disposition-ledger and
claim-accountability gaps) that keep the candidate at `deterministic_verdict: reject`. **`GC-03`
(G3 close) stays blocked** pending that defect's resolution — the run has not reached
`AWAITING_GLOBAL_HUMAN_REVIEW` because G3 onward (G4: T6/T7A/T7B/TP-11A/T8, G5: T9/TW-02, G6:
TU-01/TG-06A/TG-06B, G7: T7C-F/TP-11B/TF-01/TG-06C/T11/T13/TG-07, G8: T12/TW-04/TW-05/TG-08)
remain unstarted — genuine remaining scope, not a blocker.

## What is genuinely done and verified

- **TL-01 — RESOLVED** (explicit user authorization, recorded with exact scope).
- **G2 CLOSED (GC-02 COMPLETE).** All 11 mandatory G2 cards verified COMPLETE:
  - **T1A, T1B, T2, T10, TW-01, TW-03, TA-01, TD-01 — COMPLETE** (unchanged from prior rounds).
  - **T3 — COMPLETE.** 89-check vendored battery registry, systematic fail-closed fixture
    coverage, `docs/readme-process.md` with a live drift test. 108 tests.
  - **T4 — COMPLETE this round.** 9 of the vendored module's real 11 `_detect_*` functions
    adapted (the card's own "13 vendored detectors" text was a stale prose count, corrected by
    direct `grep` verification — the same error class as T3's "81 checks", real: 89). This
    round added the card's two remaining owned deliverables:
    - `ComposerFactpack` (`src/readme_agent/facts/composer_factpack.py`, new): merges the
      caller-supplied `ProductFactsV2` (this repo's existing, provenance-complete fact type, 55
      downstream consumers) with `AsposeDetectionBundleV1` (all 9 adapted detectors' outputs).
      `ProductFactsV2` stays sole authority for every required field; the merge never
      re-derives or overrides a selected fact (verified: the factpack carries the caller's exact
      `ProductFactsV2` instance through unchanged).
    - `EvidenceGroundedRenderViewV2` (new view in `render_views.py`, existing
      `VisitorFactRenderViewV1` untouched) — closes RC1 ("grounding evidence stripped before
      composition"). Citations can point at a `ProductFactsV2` fact_id or a new aspose-detection
      evidence reference; a model validator makes "rendered phrases with zero citations" a hard
      construction failure. Fields already covered by V1 delegate to it verbatim, proven to
      preserve V1's exact output including its `None`-when-ungrounded behavior.
    - U7 per-source staleness/coverage findings (`assess_source_staleness`) — one finding per
      of 7 consumed sources, advisory only per this plan's identity-based freshness model
      (never a regeneration trigger by itself).
    - **45 T4 tests total** (30 detector + 15 new), all against real imported data
      (`cells/java`, `cells/rust`, `barcode/python`) plus synthetic edge cases.
    - Deliberate, documented, non-blocking exclusion: `_detect_available_badges` and
      `_detect_archetype_entry_raw` (2 of the real 11) were not extracted — neither is
      referenced by the new types, so adding them later is additive.
  - **T14 — COMPLETE this round.** New `presentation/sections/` package:
    `SectionRegistryEntryV1`/`SectionRegistryV1` (id/heading/order/required/composer_binding/
    section_checks/ledger_obligations/invalidation_scope), following this repo's established
    "governed data file + strict pydantic model + `load_*()`" convention (no dynamic
    plugin-discovery pattern exists anywhere in this codebase). `templates/readme/
    section-registry-v2.json` (14 entries) is byte-derived from the live
    `template_schema.py` contract; `section_fingerprint()`/`document_global_fingerprint()`
    (the latter reusing the existing `document_template_hash()` unchanged) implement the plan's
    per-section + document-global fingerprint split. Real discrepancy found and disclosed: 20
    section-scoped checks reference headings ("Dependencies", "header", "Project Structure")
    absent from the live 14-slot contract — surfaced in `unmapped_section_checks`, not silently
    dropped, left open since fixing the shared contract exceeds T14's scope. All 4 named
    "agility tests" (a-d) implemented and green. 13 tests.
  - **T5 — substantial progress, NOT complete.** Real pilot run against the real, network-
    confirmed target repo `aspose-cells-foss/Aspose.Cells-FOSS-for-Python` (`main` @
    `26c3bd1633e84b91c0f6fad1fd353662fd61fb54`) via `readme-agent poc`, the sanctioned local-
    candidate tool. **Byte-identical double run proven twice over**: two independent
    invocations produced identical `README.md` bytes; run 2 reused the hash-bound plan (zero
    new LLM calls), corroborated independently by the pipeline's own `noop.json`
    (`verdict: RENDER_REPRODUCIBLE`, `new_provider_call_count: 0`). **Docker isolation
    machinery proven live**: the diagnostic path's own example-presence check is a static
    substring match (verified by reading its source, not assumed), so the normally-excluded
    `@pytest.mark.live` Docker tests were run explicitly instead — 2/2 passed against a real
    container. **Not achieved, disclosed not force-passed**: "full battery green" — the real
    `validation.json` reports `deterministic_verdict: reject` (9 claim-accountability gaps, 9
    protected-content losses, a structurally invalid disposition ledger) — genuine, pre-existing
    defects in the soon-to-retire agentic composer path (scheduled for retirement at `T12` once
    `T6`-`T8` build the new deterministic pipeline), out of proportion to fix within a "pilot
    skeleton" card. `GC-03` stays blocked.
- **Full governed suite, final confirmation: 3,908 passed, 1 skipped, 0 failed** (297s) — up
  from 3,880/1/0 three rounds ago; the delta is exactly 28 new tests (15 T4 + 13 T14; T5 added
  evidence only, no source changes), zero regressions throughout.
- **Twelve commits** on `freshness-service/integration` (`13286e0c4` … `9dedc1d60`; current HEAD
  `9dedc1d60`). The user's main worktree has remained byte-identical for the entire session
  (HEAD `8cb9afabeb31b69e6948a33a7502d89952caf701`, unchanged; only its pre-existing protected
  dirty paths and additive untracked evidence dirs present). Nothing pushed, no target
  repository touched (the pilot run was a real `git clone` read + local candidate generation
  only — TW-01's guard covers write operations, which never occurred).

## Honestly disclosed process gap (found and recorded this round, not silenced)

Several G2 cards (T1A, T1B, T2, T10, TA-01, TD-01, TL-01, TW-01, TW-03) do not have a dedicated
per-card evidence directory the way T3/T4/TB-01/TS-03/GC-00 do — their real work and tests exist
(verified in commit history and the full suite), but the evidence-directory convention was not
retroactively applied to them. Recorded in `freshness-service-gc-02/closeout.md` rather than
either fabricating empty retroactive directories or silently omitting the gap. Not a blocker (the
underlying work is real and tested); a legitimate housekeeping item for a future round.

## Remaining genuine external-authority blockers

1. Production hosted proof — user push + workflow dispatch (also serves as App-installation
   proof for the two Java-family orgs).
2. Two missing repo secrets (`LLM_BASE_URL`, `LLM_API_KEY`).

TL-01 is resolved and no longer a blocker.

## Not attempted / incomplete (honest, not fabricated)

`T5` (deterministic pilot skeleton, cells/python; `T14` COMPLETE) made real, substantial
progress this round (byte-identical double-run proof, live Docker capability proof) but did not
reach COMPLETE — a genuine defect in the pre-existing agentic composer path
(disposition-ledger/claim-accountability gaps, detailed in `freshness-service-t5/closeout.md`)
keeps its candidate at `deterministic_verdict: reject`; `GC-03` (G3 close) requires T5 COMPLETE
and stays blocked. `T6`, `T7A`-`T7F`, `TP-11A/B`, `TW-02`, `TU-01`, `TG-06A/B`, `TF-01`, `T11`,
`T13`, `TG-07`, `T12`, `TW-04`, `TW-05`, `TG-08` were not started. Each represents comparable
engineering scope to what's already been built;
completing them with the same rigor applied throughout this session is realistically a
multi-session undertaking.
